CREATE Procedure [dbo].[My] as
SELECT * FROM [dbo].[EMPLOYEE];
go

